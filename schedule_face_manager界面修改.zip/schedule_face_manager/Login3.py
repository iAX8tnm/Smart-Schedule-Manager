#-*-coding:utf-8-*-

import cv2
import numpy
import time
#import uniout
import os
import sys
from Lib.facecpp import *
from Lib.cv2fn import detect_face
import config as gl
sys.path.append('home/pi/schedule_face_manager/Smart')

from main import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from gui.login_window import *

is_take_pic = False
is_exit = False

class mLoginWindow(QMainWindow, Ui_login_window):
    def __init__(self, parent = None):
        super(mLoginWindow, self).__init__(parent)
        self.setupUi(self)

        self.video = None
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.play)

    def play(self):
        try:
            self.video.captureNextFrame()
            self.pic_people.setPixmap(self.video.convertFrame())
            self.pic_people.setScaledContents(True)
        except TypeError:
            print('No Frame')

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()


class Video():
    def __init__(self, capture):
        self.capture = capture
        self.currentFrame = np.array([])
    
    def captureFrame(self):
        ret, readFrame = self.capture.read()
        return readFrame
    
    def captureNextFrame(self):
        ret, readFrame = self.capture.read()
        if (ret == True):
            self.currentFrame = cv2.cvtColor(readFrame, cv2.COLOR_BGR2RGB)
    
    def convertFrame(self):
        try:
            height, width = self.currentFrame.shape[:2]
            img = QImage(self.currentFrame, width, height, QImage.Format_RGB888)
            img = QPixmap.fromImage(img)
            self.previousFrame = self.currentFrame
            return img
        except:
            return None

def set_is_take_pic_login():
	global is_take_pic
	is_take_pic = True

def set_is_exit_login():
    global is_exit
    is_exit = True

def login(mThread, mWindow):
	global is_take_pic
	global is_exit
	facedict = gl.get_facedict()

	while not is_exit:
		while not is_take_pic:
			pass	
		print('yes')
		if not is_exit:
			ret, img = mWindow.video.capture.read()
			faces = detect_face(img)
			print(faces)
			if len(faces) == 1:
				cv2.imwrite("/home/pi/schedule_face_manager/wt.jpg",img,[int(cv2.IMWRITE_JPEG_QUALITY),80])
				face_state=1
			elif len(faces) == 0:
				print('No face found')
				mThread.trigger_call_window.emit('NO_FACE_LOGIN')				#todo
				face_state=0			
			else:
				print('More than one face found')
				mThread.trigger_call_window.emit('MORE_FACE_LOGIN')				#todo
				face_state=0		
			if face_state ==1:
				mWindow.video.capture.release()

				pictureId = upload_img1("/home/pi/schedule_face_manager/wt.jpg")
				if len(pictureId) > 0:
					facetoken,confidence = search(pictureId,'myface')
				if confidence > 75:
					print(facetoken)
					if facetoken in facedict.keys():
						mThread.trigger_call_window.emit('SUCCESS_LOGIN')		#todo
						person=facedict[facetoken]
						print('ok')
						print(person)
						print(confidence)
						mThread.trigger_call_window.emit('CALL_CHAT')
						init_personlist_in_main()
						FSM(person, mThread)
						
						break
					else:
						print('failed')
						print(confidence)
				else:
					print('sorry, you don not have the root')
					print(confidence)
				break
			else:
				#恢复现场， 重来拍照登录
				is_take_pic = False
				is_exit = False
				mThread.trigger_call_window.emit('RESTART_TIMER_LOGIN')
			continue
		
	mThread.trigger_call_window.emit('CLOSE_LOGIN')
	is_take_pic = False
	is_exit = False



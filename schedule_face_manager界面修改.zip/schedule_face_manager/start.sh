#!/bin/bash
#keyboard
python3 /home/pi/schedule_face_manager/firstpage.py &

exit 0
# face--opencv

# 环境及硬件配置
  #python3
  #opencv
  #numpy
  #RPi.GPIO
  #USB摄像头
  #人体红外模块



# firstpage.py
  #显示的第一个界面

# Login3.py
  #登陆界面

# SetAccount1.py
  #设置人脸帐号

# SetAccount.py
  #设置faceset帐号

# Removeface.py
  #删除faceset（myface）里的人脸

# DeletAccoynt.py
  #删除一个faceset

# SetAccount2.py
  #设置人脸帐号（可摄像头显示人脸，还不ok）

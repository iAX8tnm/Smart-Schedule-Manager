#-*-coding:utf-8-*-

import cv2
import numpy
import time
#import uniout
import os
import sys
import itchat
import RPi.GPIO as GPIO

from Lib.facecpp import *
#from person import personlist
from person import Person
from TeaTime import time_stamp
import pickle

from Login3 import *
from SetAccount1 import *
from main import *

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from gui.clock_window import *
from gui.login_window import *
from gui.select_window import *
from gui.msg_window import *            #todo

import config as gl

select = ''    #global value

#################################################################
class WorkThread(QThread):
    trigger_close_win = pyqtSignal()
    trigger_update_UI = pyqtSignal(dict)
    trigger_call_window = pyqtSignal(str)
    def __init__(self):
        super(WorkThread, self).__init__()
    ################工作线程的主要工作
    def run(self):
        start_wechat()
        gl.init_personlist()
        gl.init_facedict()
        init()
        detct(self)
        save_personlist()
        GPIO.cleanup(36)
        self.trigger_close_win.emit()

#################时钟界面类与其信号槽
class mClockWindow(QMainWindow, Ui_clock_window):
    def __init__(self, parent = None):
        super(mClockWindow, self).__init__(parent)
        self.setupUi(self)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)
        self.is_odd = False

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            save_personlist()
            GPIO.cleanup(36)
            self.close()

    def closeEvent(self, event):
        save_personlist()
        GPIO.cleanup(36)

    def update_time(self):
        time = QDateTime.currentDateTime()
        time_text = time.toString("hh:mm")
        if self.is_odd:
            time_text = time_text.replace(":", " ")
            self.is_odd = False
        else:
            self.is_odd = True
        self.time_display.setText(time_text)

#clock_window slots
def close_clock_win():
    workThread.stop()
    qApp = QApplication.instance()
    qApp.quit()

#################选择窗口类与其信号槽
class mSelectWindow(QMainWindow, Ui_select_window):
    def __init__(self, parent = None):
        super(mSelectWindow, self).__init__(parent)
        self.setupUi(self)

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()

#select_window_slots
def start_login():
    global select
    select = 'l'

def call_register():
    global select
    select = 's'

def close_select_win():
    global select

    select = 'q'
    select_win.close()
#################注册窗口的信号槽
def enable_btn_camera():
    register_win.btn_camera.setEnabled(True)
def enable_btn_register():
    register_win.btn_register.setEnabled(True)
def start_camera():
    register_win.set_is_start_camera()
    if not register_win.get_is_take_pic():
        register_win._timer.start(27)
    else:
        register_win._timer.stop()
        register_win.btn_camera('识别中...')        #todo
def start_register():                   
    register_win.set_is_start_register()
def close_register():
    register_win.set_close_name()
#################登录窗口的信号槽
def start_take_pic():
    set_is_take_pic_login()
    login_win._timer.stop()
    login_win.btn_take_pic.setText('识别中...')     #todo

def exit_login():
    set_is_take_pic_login()
    set_is_exit_login()
    if login_win.video.capture.isOpened():
        login_win.video.capture.release()
#################会话窗口的信号槽

def update_UI_slot(p):
    if "purpose" in p:
        if p["purpose"] == "START_RECORD":
            chat_win.ask_box.setHidden(False)
            chat_win.btn_record.setEnabled(False)
        elif p["purpose"] == "RECORD_DONE":
            chat_win.ask_box.setHidden(False)
            chat_win.btn_record.setEnabled(False)
            chat_win.ask_text.setText('识别中...')
        elif p["purpose"] == "NLP_DONE":
            pass
        elif p["purpose"] == "ASK_TEXT":
            chat_win.ask_text.setText(p["data"])
        elif p["purpose"] == "ANSWER_TEXT":
            chat_win.answer_box.setHidden(False)
            chat_win.answer_text.setText(p["data"])
        elif p["purpose"] == "ANSWER_DATA":
            if "data" in p:
                schedulelist = p["data"]
                row = 0
                for s in schedulelist:
                    chat_win.add_schedule(s, row)
                    row = row + 2
            p.pop("data")
        elif p["purpose"] == "PLAY_DONE":
            chat_win.btn_record.setEnabled(True)
        p.pop("purpose")
            
#################通知信息窗口的信号槽                           #todo
class mMessageWindow(QMainWindow, Ui_msg_window_window):
    def __init__(self, parent = None):
        super(mMessageWindow, self).__init__(parent)
        self.setupUi(self)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)
        self.is_odd = False
        self.live_timer = Qtimer()
        self.live_timer.singleShot(60000, self.close_msg)

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close_msg()

    def update_time(self):
        time = QDateTime.currentDateTime()
        time_text = time.toString("hh:mm")
        if self.is_odd:
            time_text = time_text.replace(":", " ")
            self.is_odd = False
        else:
            self.is_odd = True
        self.time_display.setText(time_text)
    
    def add_schedule(self, schedule, row):
        pass

    def add_grid(self, text, x, y):
        pass

    def clear_grid(self):
        n = self.grid_layout.count()
        for i in range(n)[::-1]:
            item = self.grid_layout.takeAt(i)
            w = item.widget()
            w.deleteLater()
    
    def close_msg(self):
        pass    #清除显示
        self.close()

#################线程trigger_call_window的信号槽
def call_window(cmd):
    if cmd == 'CALL_SELECT':
        select_win.show()
    elif cmd == 'CALL_REGISTER':
        register_win.show()
    elif cmd == 'CALL_LOGIN':
        if login_win.video == None or not login_win.video.capture.isOpened():
            login_win.video = Video(cv2.VideoCapture(0))

        login_win._timer.start(27)
        login_win.show()
    elif cmd == 'CALL_CHAT':
        chat_win.ask_box.setHidden(True)
        chat_win.show()
    elif cmd == 'CALL_MESSAGE':
        #初始化数据
        msg_win.show()
    elif cmd == 'CLOSE_SELECT':
        select_win.close()
    elif cmd == 'CLOSE_REGISTER':
        register_win.close()
    elif cmd == 'CLOSE_LOGIN':
        login_win.close()
    elif cmd == 'CLOSE_CHAT':
        chat_win.ask_text.setText('倾听中...')
        chat_win.answer_text.setText(' ')
        chat_win.ask_box.setHidden(True)
        chat_win.answer_box.setHidden(True)
        chat_win.close()
    elif cmd == 'WECHAT_QRCODE':
        register_win.show_QRcode()
    elif cmd == 'RESTART_TIMER_REGISTER':
        register_win._timer.start(27)
    elif cmd == 'NO_FACE_LOGIN':                #todo
        login_win.btn_take_pic.setText('没有找到人脸，请重来')
    elif cmd == 'MORE_FACE_LOGIN':
        login_win.btn_take_pic.setText('找到多张人脸，请重来')
    elif cmd == 'SUCCESS_LOGIN':
        login_win.btn_take_pic.setText('登陆成功')
    elif cmd == 'NO_FACE_REGISTER':
        register_win.btn_camera.setText('没有找到人脸，请重来')
    elif cmd == 'SUCCESS_REGISTER':
        register_win.btn_camera.setText('找到多张人脸，请重来')
    elif cmd == 'MORE_FACE_REGISTER':
        register_win.btn_camera.setText('登陆成功')
    elif cmd == 'RESTART_TIMER_LOGIN':
        login_win._timer.start(27)
    elif cmd == 'CALL_KEYBOARD':
        subprocess.Popen('matchbox-keyboard', shell = True)
    elif cmd == 'CLOSE_KEYBOARD':
        pass
################################################################

#初始化
def init():
    #设置不显示警告
    GPIO.setwarnings(False)
    #设置读取面板针脚模式
    GPIO.setmode(GPIO.BOARD)
    #设置读取针脚标号
    GPIO.setup(36,GPIO.IN,pull_up_down = GPIO.PUD_UP)
    pass

#启动微信机器人
def start_wechat():
    itchat.auto_login(hotReload = True, enableCmdQR = 2)

#备份personlist
def save_personlist():
    print('saving data')
    personlist = gl.get_personlist()
    try:
        f = open('person_list.pickle','wb+')
        pickle.dump(personlist,f)
        f.close()
    except:
        print('储存失败')
    print(personlist)

def detct(mThread):
    global select
    while True:
        #当高电平信号输入时报警
        if GPIO.input(36) == False:
            #show 第二个窗口，选择窗口
            #选择窗口的按键connect到自定义槽中,自定义槽执行相关操作
            mThread.trigger_call_window.emit('CALL_SELECT')
            #################################################################
            task = threading.Thread(target=time_stamp)    #线程：时间戳遍历
            task.start()
            print ('What do you want to do?(Set account(s) or Log in(l) or exit(q))')

            while select == '':   #hang on
                pass
            
            if select == 'q': 
                select = ''
            if select == 's':
                 mThread.trigger_call_window.emit('CALL_REGISTER')
                 mThread.trigger_call_window.emit('CLOSE_SELECT')
                 SetAccount(mThread, register_win)
                 mThread.trigger_call_window.emit('CLOSE_REGISTER')
                 select = ''
            if select == 'l':
                 mThread.trigger_call_window.emit('CALL_LOGIN')
                 mThread.trigger_call_window.emit('CLOSE_SELECT')
                 login(mThread, login_win)
                 select = ''
        else:
            continue
        time.sleep(3)
    select = ''

if __name__ == '__main__':

    app = QApplication(sys.argv)

    clock_win = mClockWindow()

    select_win = mSelectWindow()
    select_win.btn_login.clicked.connect(start_login)
    select_win.btn_register.clicked.connect(call_register)
    select_win.btn_exit.clicked.connect(close_select_win)
    
    login_win = mLoginWindow()
    login_win.btn_take_pic.clicked.connect(start_take_pic)
    login_win.btn_exit.clicked.connect(exit_login)


    register_win = mRegisterWindow()
    register_win.btn_camera.setEnabled(False)
    register_win.btn_register.setEnabled(False)
    register_win.edit_name.textChanged.connect(enable_btn_camera)

    register_win.btn_camera.clicked.connect(start_camera)
    register_win.btn_register.clicked.connect(start_register)
    register_win.btn_exit.clicked.connect(close_register)

    chat_win = mChatWindow()
    chat_win.btn_record.clicked.connect(chat_win.start_record)
    chat_win.ask_box.setHidden(True)
    chat_win.answer_box.setHidden(True)

    msg_win = mMessageWindow()
    msg_win.btn_know.clicked.connect(msg_win.close_msg)

    

    workThread = WorkThread()
    workThread.trigger_close_win.connect(close_clock_win)
    workThread.trigger_update_UI.connect(update_UI_slot)
    workThread.trigger_call_window.connect(call_window)
    workThread.start()
    
    clock_win.show()
    sys.exit(app.exec_())

############################################

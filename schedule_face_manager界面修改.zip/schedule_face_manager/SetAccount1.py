#-*-coding:utf-8-*-

import sys
import pickle
from Lib.facecpp import *
from Lib.cv2fn import detect_face
#from person import personlist
from person import Person
import threading
import time
from TeaTime import wechat_time
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from gui.register_window import *
from gui.qrcode_dialog import *
import config as gl

name = ''
is_start_camera = False
is_start_register = False
is_take_pic_done = False
is_exit = False

###################################################################

class mDialog(QDialog, Ui_qrcode_dialog):
    def __init__(self, parent = None):
        super(mDialog, self).__init__(parent)
        self.setupUi(self)


class mRegisterWindow(QMainWindow, Ui_register_window):
    def __init__(self, parent = None):
        super(mRegisterWindow, self).__init__(parent)
        self.setupUi(self)
        self.video = None
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.play)

    def play(self):
        try:
            self.video.captureNextFrame()
            self.pic_face.setPixmap(self.video.convertFrame())
            self.pic_face.setScaledContents(True)
        except TypeError:
            print('No Frame')

    def show_QRcode(self):
        dialog = mDialog()
        r = dialog.exec_()
        if r == QDialog.Accepted:
            print('accepted')
            task = threading.Thread(target=wechat_time,args=(name,))	#线程：得到当前加的好友昵称
            task.start()
        elif r == QDialog.Rejected:
            pass
            print('rejected')
        else:
            print('.......')
    def set_is_start_camera(self):                  #应该在这里判断是第几次按下，第一次按下启动窗口的定时器，实时显示
        global name                                           #第二次按下则是真正的拍照，结束窗口定时器
        global is_start_camera
        global is_take_pic_done

        if not is_start_camera:
            name = self.edit_name.text()
            self.video = Video(cv2.VideoCapture(0))
            if not self.video.capture.isOpened(): print('Cap failed because of camera')
            self.btn_camera.setText('确认')
            if name != '' and name != 'q':
                is_start_camera = True
        else:
            is_start_camera = False
            self._timer.stop()
            is_take_pic_done = True
            self.btn_register.setEnabled(True)

		    
    def set_is_start_register(self):
        global is_start_register
        if name != '' and name != 'q' and is_take_pic_done:
            is_start_register = True

    def set_close_name(self):
        global name
        global is_start_register
        global is_exit
        is_exit = True
        name = 'q'
        is_start_register = True

    def get_is_take_pic(self):
        return is_take_pic_done
		
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()

class Video():
    def __init__(self, capture):
        self.capture = capture
        self.currentFrame = np.array([])
    
    def captureFrame(self):
        ret, readFrame = self.capture.read()
        return readFrame
    
    def captureNextFrame(self):
        ret, readFrame = self.capture.read()
        if (ret == True):
            self.currentFrame = cv2.cvtColor(readFrame, cv2.COLOR_BGR2RGB)
    
    def convertFrame(self):
        try:
            height, width = self.currentFrame.shape[:2]
            img = QImage(self.currentFrame, width, height, QImage.Format_RGB888)
            img = QPixmap.fromImage(img)
            self.previousFrame = self.currentFrame
            return img
        except:
            return None
###################################################################

existFaceName=[]

def SetAccount(mThread, mWindow):			#先输入名字，文本改变后enable拍照按键，输入完成后，点击拍照按键
				                                                        #启动拍照显示的定时器实时显示，拍照按键变成确认按键，确认即拍照
	global name                                                          #拍完后延时一秒，跳出二维码窗口，扫描微信二维码，扫完确认退出
	global is_start_camera                                         #enable注册按键，点击注册按键注册
	global is_start_register
	global is_take_pic_done
	global is_exit


	if not os.path.exists('picture'): os.mkdir('picture')

	mThread.trigger_call_window.emit('CALL_KEYBOARD')
	while 1:
		print('What\'s the name of the account you want to set?(q to exit) ')
		while name == '':                                               #等待名字的输入
			pass
		facedict = gl.get_facedict()
		if name == 'q': break
		for k,v in facedict.items():
			existFaceName.append(v)

		flag_exit = False
		while not is_start_camera:                               #等待按拍照
			if is_exit:
				flag_exit = True
				break
		if flag_exit or is_exit:
			break
		flag_exit = False
		while not is_take_pic_done:                              #等待确认拍照
			if is_exit:
				flag_exit = True
				break
		if flag_exit or is_exit:
			mThread.trigger_call_window.emit('EXIT_WHEN_TAKE_REGISTER')
			break             
		ret, img = mWindow.video.capture.read()       #拍照
		faces = detect_face(img)
		print(faces)
		if len(faces) == 1:
			cv2.imwrite(os.path.join('picture', 'pic1.jpg'), img)
			face_state=1
		elif len(faces) == 0:
			print('No face found')
			mThread.trigger_call_window.emit('NO_FACE_REGISTER')
			face_state=0
		else:
			print('More than one face found')
			mThread.trigger_call_window.emit('MORE_FACE_REGISTER')
			face_state=0
		mWindow.video.capture.release()
		if face_state ==1:
			pictureList = [os.path.join('picture', 'pic1.jpg')]
		else:
			pictureList = None
			#Dialog提示，恢复现场，重新拍照
			is_start_camera = False
			is_take_pic_done = False
			mThread.trigger_call_window.emit('RESTART_TIMER_REGISTER')
			mWindow.set_is_start_camera()
			continue

		mThread.trigger_call_window.emit('TAKE_PIC_SUCCESS_REGISTER')
		#在这里显示二维码询问是否添加微信机器人， dialog上显示二维码
		print('Do you want to accept from wechat?(y or n)')
		mThread.trigger_call_window.emit("WECHAT_QRCODE")
		
		flag_exit = False
		while not is_start_register:
			if is_exit:
				flag_exit = True
				print('r1')
				break
		if flag_exit or is_exit:
			print('r2')
			break
		print('r3')
		if pictureList is not None:
			faceIdList = upload_img(pictureList)
			print ('%s samples are set'%len(faceIdList))
			for x in faceIdList:
				gl.set_facedict(x, name)
			f = open('facedict.pickle','wb+')
			pickle.dump(gl.get_facedict(), f)
			f.close()
			
			#开始注册
			add_face('myface', faceIdList)
			print('Account [%s] is set'%name)
			mThread.trigger_call_window.emit('SUCCESS_REGISTER')
			user = Person(name) 

			gl.set_personlist(name, user)
			t = gl.get_personlist()
			for key in t:
				print(key)
			break
		else:
			break
	name = ''
	is_start_camera = False
	is_start_register = False
	is_take_pic_done = False
	is_exit = False



	

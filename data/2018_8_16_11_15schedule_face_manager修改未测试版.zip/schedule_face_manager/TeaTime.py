#-*-coding:utf-8-*-

#####################     新加的文件       ##############

from schedule import Schedule
import time 
from person import personlist
from person import Person
from schedule import Schedule

import datetime
import itchat
import re
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.schedulers.blocking import BlockingScheduler
import pytz
import matplotlib.pyplot as plt

import os

timez = pytz.timezone('Asia/Shanghai')
timestamp=[]        #所有时间戳
thingstamp=[]       #所有事情
time_list={}         #创建空字典放置account和对应的时间戳列表
thing_list={}         #创建空字典放置account和对应的事情列表
name_list={}         #创建空字典放置account和friend_name
timestamp_list=[]   #所有行程的时间戳列表

def get_list():
    friends = itchat.get_friends(update=True)[0:]
    tList = []
    for i in friends:
    #用正则表达式过滤掉 span ，class，emoji。NickName表示微信好友的昵称；
        signature = i["NickName"].strip().replace("span","").replace("class","").replace("emoji","")
        rep = re.compile("1f\d.+")
        signature = rep.sub("",signature)
#    print(signature)
        tList.append(signature)
    return tList[1]


# 发送消息
def send_news(friend_name,time_message):
    try:
        my_friend = itchat.search_friends(name=friend_name)  # name改成人在你微信的备注
        name = my_friend[0]["UserName"]
        message = time_message
        itchat.send(message, toUserName=name)
#        Timer(10, send_news).start()  # 每隔86400秒发送一次，也就是每天发一次
    except:
        message1 = "cool"
        itchat.send(message1, toUserName=name)



# 1440751417.283 --> '2015-08-28 16:43:37.283'
def timestamp2string(timeStamp):
    try:
        d = datetime.datetime.fromtimestamp(timeStamp)
        str1 = d.strftime("%Y-%m-%d %H:%M:%S.%f")
        # 2015-08-28 16:43:37.283000'
        return str1
    except Exception as e:
        print (e)
        return ''

#得到所有的时间戳及事情
def get_timedict():
    for key in personlist.keys():
        print(key)
        value = personlist[key]
        timelist = value.get_scheduleList()
        for x in timelist:
            timestamp.append(x.get_timestamp())
            thingstamp.append(x.get_thing())
        print(timestamp)
        print(thingstamp)
        time_list[key]=timestamp
        thing_list[key]=thingstamp
    return time_list,thing_list
 
def compare(e_time, n_time ):
    if e_time ==  n_time:
        return 0
    else:
        return -1

def wechat_time(name):
    first_friend = get_list()
    name_list[first_friend] = name
    return name_list



#遍历时间戳
def time_stamp():
    time_list,thing_list = get_timedict()
    for key in time_list.keys():
        timestamp_list.extend(time_list[key])
    print (timestamp_list)

#这里是打印出某个人什么时间干什么事情，并给微信发送消息

    for x in timestamp_list:
        if (compare(int(time.time()),int(x))) == 0:
            key_time = timestamp2string(x)
            for key in time_list.keys():
                special_list = time_list[key]           #某个名字的时间戳列表
                if x in time_list[key]:    
                    num = special_list.index(x)             #得到x这个时间戳在列表中的下标
                    key_name = key
                    key_thing = (thing_list[key])[num]
                    print (key_name)
                    if key in name_list.keys():
                        friendname = name_list[key]
                        send_news(friendname,'It is your Tea Time'+key_time+key_thing)
                else:
                    continue
            print(key_name,'It is your Tea Time',key_time,key_thing)
            os.system('omxplayer Flo Rida-Whistle.mp3')







        


#!/bin/bash
sudo cp /gui/res/monospace/* /etc/share/fonts/truetype/monospace/
#-*-coding:utf-8-*-

import cv2
import numpy
import time
#import uniout
import os
import sys
import RPi.GPIO as GPIO

from Lib.facecpp import *

#edit by mumumushi 2018/8/14/14:36###########
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from Smart.gui.clock_window import *
from Smart.gui.login_window import *

from Smart.gui.select_window import *

select = ''    #global value


class WorkThread(QThread):
    trigger_close_win = pyqtSignal()
    trigger_update_UI = pyqtSignal(dict)
    
    def __init__(self):
        super(WorkThread, self).__init__()
    
    def run(self):
        time.sleep(2)
        init()
        detct()
        GPIO.cleanup()
        self.trigger_close_win.emit()

class mClockWindow(QMainWindow, Ui_clock_Window):
    def __init__(self, parent = None):
        super(mMainWindow, self).__init__(parent)
        self.setupUi(self)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)
        self.is_odd = False


    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()

    def update_time(self):
        time = QDateTime.currentDateTime()
        time_text = time.toString("hh:mm")
        if self.is_odd:
            time_text = time_text.replace(":", " ")
            self.is_odd = False
        else:
            self.is_odd = True
        self.time_display.setText(time_text)

class mSelectWindow(QMainWindow, Ui_select_window):
    def __init__(self, parent = None):
        super(mMainWindow, self).__init__(parent)
        self.setupUi(self)


    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()



class mLoginWindow(QMainWindow, Ui_login_window):
    def __init__(self, parent = None):
        super(mLoginWindow, self).__init__(parent)
        self.setupUi(self)


    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()


#clock_window slots
def close_clock_win():
    #print("do u?")
    workThread.stop()
    qApp = QApplication.instance()
    qApp.quit()

def update_UI_slot(p):
    #print("yes")
    if "purpose" in p:
        pass


#select_window_slots
def start_login():
    global select
    select = 'l'
   
   

def call_register():
    global select
    select = 's'
    
    

def close_select_win():
    global select
    select = 'q'
    select_win.close()

############################################



#初始化
def init():
    #设置不显示警告
    GPIO.setwarnings(False)
    #设置读取面板针脚模式
    GPIO.setmode(GPIO.BOARD)
    #设置读取针脚标号
    GPIO.setup(36,GPIO.IN)
    pass


def detct():
    

    while True:
        #当高电平信号输入时报警
        if GPIO.input(36)==True:
            #show 第二个窗口，选择窗口
            #选择窗口的按键connect到自定义槽中,自定义槽执行相关操作
            select_win.show()
            print ('What do you want to do?(Set account(s) or Log in(l) or exit(q))')
            while select == '':   #hang out
                pass
            
            if select == 'q': 
                break
            if select == 's':
#                os.popen('home/lalala/face测试/SetAccount1.py')
                 os.system('python3 SetAccount1.py')
            #if select == 'r':
#                os.popen('home/lalala/face测试/Removeface.py')
                 #os.system('python3 Removeface.py')
            if select == 'l':
#                os.popen('home/lalala/face测试/Login3.py')
                 os.system('python3 Login3.py')
        else:
            continue
        time.sleep(3)

#edit by mumumushi 2018/8/14/14:36###########
if __name__ == '__main__':

    app = QApplication(sys.argv)

    clock_win = mClockWindow()

    select_win = mSelectWindow()
    select_win.btn_login.clicked.connect(start_login)
    select_win.btn_register.clicked.connect(call_register)
    select_win.btn_exit.clicked.connect(close_select_win)

    register_win = mRegisterWindow()

    login_win =  mLoginWindow()

    workThread = WorkThread()
    workThread.start()
    workThread.trigger_close_win.connect(close_clock_win)
    workThread.trigger_update_UI.connect(update_UI_slot)
    
    clock_win.show()


############################################
#-*-coding:utf-8-*-

import cv2
import numpy
import time
#import uniout
import os
import sys
from Lib.facecpp import *
from Lib.cv2fn import take_picture
from SetAccount1 import facedict

sys.path.append('home/pi/schedule_face_manager/Smart')
#edit by mumumushi 2018/8/14/14:36###########
from main import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from gui.login_window import *

isStart_take_pic = False

class mLoginWindow(QMainWindow, Ui_login_window):
    def __init__(self, parent = None):
        super(mLoginWindow, self).__init__(parent)
        self.setupUi(self)


    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()


def start_take_pic():
	global isStart_take_pic
	isStart_take_pic = True


def login(mThread):
	while not isStart_take_pic:
		pass
	capInput = cv2.VideoCapture(0)
	if not capInput.isOpened(): print('Capture failed because of camera')
	while 1:
		ret, img = capInput.read()
		cv2.imwrite(os.getcwd() + "/wt.jpg",img,[int(cv2.IMWRITE_JPEG_QUALITY),80])
		capInput.release()
		pictureId = upload_img1(os.getcwd() + "/wt.jpg")
		if len(pictureId) > 0:
			facetoken,confidence = search(pictureId,'myface')
		if confidence > 75:
			print(facetoken)
			if facetoken in facedict.keys():
				person=facedict[facetoken]
				print('ok')
				print(person)
				print(confidence)
				mThread.trigger_call_window.emit('CALL_CHAT')
				mThread.trigger_call_window.emit('CLOSE_LOGIN')				
				FSM(person, mThread)
			else:
				print('failed')
				print(confidence)
		else:
			print('sorry, you don not have the root')
			print(confidence)
		break
    



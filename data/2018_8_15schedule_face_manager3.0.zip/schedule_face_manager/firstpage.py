#-*-coding:utf-8-*-

import cv2
import numpy
import time
#import uniout
import os
import sys
import RPi.GPIO as GPIO
##################################################################
from Lib.facecpp import *
from person import personlist
from person import Person
from TeaTime import time_stamp
import pickle
###############################################edit by mumumushi 8/15/
from Login3 import *
from SetAccount1 import *
from main import *

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from gui.clock_window import *
from gui.login_window import *
from gui.select_window import *

select = ''    #global value

################################################################
if not os.path.exists('person_list.pickle'):
    person_list={}
else:
    try:
	    f = open('personlist.pickle','rb')
	    person_list=pickle.load(f)
	    f.close
    except EOFError:
        pass

#################################################################
class WorkThread(QThread):
    trigger_close_win = pyqtSignal()
    trigger_update_UI = pyqtSignal(dict)
    trigger_call_window = pyqtSignal(str)
    def __init__(self):
        super(WorkThread, self).__init__()
    ################工作线程的主要工作#################################
    def run(self):
        time.sleep(2)
        init()
        detct(self)
        GPIO.cleanup()
        save_personlist()
        self.trigger_close_win.emit()

#################时钟界面类与其信号槽##############################
class mClockWindow(QMainWindow, Ui_clock_window):
    def __init__(self, parent = None):
        super(mClockWindow, self).__init__(parent)
        self.setupUi(self)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)
        self.is_odd = False

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()

    def update_time(self):
        time = QDateTime.currentDateTime()
        time_text = time.toString("hh:mm")
        if self.is_odd:
            time_text = time_text.replace(":", " ")
            self.is_odd = False
        else:
            self.is_odd = True
        self.time_display.setText(time_text)

#clock_window slots
def close_clock_win():
    #print("do u?")
    workThread.stop()
    qApp = QApplication.instance()

    qApp.quit()

#################选择窗口类与其信号槽##############################
class mSelectWindow(QMainWindow, Ui_select_window):
    def __init__(self, parent = None):
        super(mSelectWindow, self).__init__(parent)
        self.setupUi(self)


    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()

#select_window_slots
def start_login():
    global select
    select = 'l'

def call_register():
    global select
    select = 's'

def close_select_win():
    global select

    select = 'q'
    select_win.close()
#################注册窗口的信号槽##############################
def enable_btn_camera():
	register_win.btn_camera.setEnable(True)

def start_camera():
	global name
	name = register_win.edit_name.Text()
	#call camera

def start_register():
	global isStartRegister
	if name != '' and name != 'q':
		isStartRegister = True

def close_register():
	global name
	name = 'q'

#################登录窗口的信号槽##############################
def start_take_pic():
	global isStart_take_pic
	isStart_take_pic = True
#################会话窗口的信号槽##############################

def update_UI_slot(p):
    print("yes")
    if "purpose" in p:
        if p["purpose"] == "START_RECORD":
            chat_win.ask_box.setHidden(False)
        elif p["purpose"] == "RECORD_DONE":
            pass
        elif p["purpose"] == "ASK_TEXT":
            chat_win.ask_text.setText(p["data"])
        elif p["purpose"] == "ANSWER_TEXT":
            chat_win.answer_box.setHidden(False)
            chat_win.answer_text.setText(p["data"])
        elif p["purpose"] == "ANSWER_DATA":
            if "data" in p:
                schedulelist = p["data"]
                row = 0
                for s in schedulelist:
                    chat_win.add_schedule(s, row)
                    row = row + 2
            p.pop("data")
        elif p["purpose"] == "PLAY_DONE":
            pass


#################线程trigger_call_window的信号槽#####################
def call_window(cmd):
    if cmd == 'CALL_SELECT':
        select_win.show()
    elif cmd == 'CALL_REGISTER':
        register_win.show()
    elif cmd == 'CALL_LOGIN':
        login_win.show()
    elif cmd == 'CALL_CHAT':
        chat_win.show()
    elif cmd == 'CLOSE_SELECT':
        select_win.close()
    elif cmd == 'CLOSE_REGISTER':
        register_win.show()
    elif cmd == 'CLOSE_LOGIN':
        login_win.close()
    elif cmd == 'CLOSE_CHAT':
        chat_win.close()

################################################################

#初始化
def init():
    #设置不显示警告
    GPIO.setwarnings(False)
    #设置读取面板针脚模式
    GPIO.setmode(GPIO.BOARD)
    #设置读取针脚标号
    GPIO.setup(36,GPIO.IN)
    pass

#备份personlist
def save_personlist():
    f = open('person_list.pickle','wb')
    pickle.dump(personlist,f)
    f.close()

def detct(mThread):
    
    while True:
        #当高电平信号输入时报警
        if GPIO.input(36)==True:
            #show 第二个窗口，选择窗口
            #选择窗口的按键connect到自定义槽中,自定义槽执行相关操作
            mThread.trigger_call_window.emit('CALL_SELECT')
            #################################################################
            task = threading.Thread(target=time_stamp)    #线程：时间戳遍历
            task.start()
            print ('What do you want to do?(Set account(s) or Log in(l) or exit(q))')

            while select == '':   #hang out
                pass
            
            if select == 'q': 
                pass
            if select == 's':
                 mThread.trigger_call_window.emit('CALL_REGISTER')
                 mThread.trigger_call_window.emit('CLOSE_SELECT')
                 SetAccount()
            if select == 'l':
                 mThread.trigger_call_window.emit('CALL_LOGIN')
                 mThread.trigger_call_window.emit('CLOSE_SELECT')
                 login(mThread)
        else:
            continue
        time.sleep(3)

if __name__ == '__main__':

    app = QApplication(sys.argv)

    clock_win = mClockWindow()

    select_win = mSelectWindow()
    select_win.btn_login.clicked.connect(start_login)
    select_win.btn_register.clicked.connect(call_register)
    select_win.btn_exit.clicked.connect(close_select_win)
    
    clock_win.show()
    
    login_win = mLoginWindow()
    login_win.btn_take_pic.clicked.connect(start_take_pic)


    register_win = mRegisterWindow()
    register_win.edit_name.textChanged.connect(enable_btn_camera)

    register_win.btn_camera.clicked.connect(start_camera)
    register_win.btn_register.clicked.connect(start_register)
    register_win.btn_exit.clicked.connect(close_register)

    chat_win = mChatWindow()
    chat_win.btn_record.clicked.connect(chat_win.start_record)
    chat_win.ask_box.setHidden(True)
    chat_win.answer_box.setHidden(True)
    

    workThread = WorkThread()
    workThread.trigger_close_win.connect(close_clock_win)
    workThread.trigger_update_UI.connect(update_UI_slot)
    workThread.trigger_call_window.connect(call_window)
    workThread.start()

    sys.exit(app.exec_())

############################################

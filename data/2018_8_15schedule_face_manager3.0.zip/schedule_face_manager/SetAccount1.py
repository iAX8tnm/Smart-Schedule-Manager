#-*-coding:utf-8-*-

import sys
import pickle
from Lib.facecpp import *
from Lib.cv2fn import take_picture
from person import personlist
from person import Person
import threading
import time
from TeaTime import wechat_time
import matplotlib.pyplot as plt
#edit by mumumushi 2018/8/14/14:36###########
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from gui.register_window import *

name = ''
isStartRegister = False

class mRegisterWindow(QMainWindow, Ui_register_window):
    def __init__(self, parent = None):
        super(mRegisterWindow, self).__init__(parent)
        self.setupUi(self)


    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()

#existFacesetName = [facesets['outer_id'] for facesets in get_faceset_list()]
if not os.path.exists('facedict.pickle'):
	facedict={}
else:
	try:
		f = open('facedict.pickle','rb')
		facedict=pickle.load(f)
		f.close
	except EOFError:
		pass


existFaceName=[]

def SetAccount():
	global personlist
	while 1:
        
#        print('Here is the list of faceset recorded:\n' +
#            '\n'.join(['* ' + outer_id for outer_id in existFacesetName]) + '\nEnd of List')

		print('What\'s the name of the account you want to set?(q to exit) ')
		while name == '':
			pass

		if name == 'q': break
		for k,v in facedict.items():
			existFaceName.append(v)

		print('you should input one picture as a sample')
#        picNum = int(input('How much picture do you want to input as sample? ')) or 10
		pictureList = take_picture(1)
		if pictureList is not None:
			faceIdList = upload_img(pictureList)
			print ('%s samples are set'%len(faceIdList))
			for x in faceIdList:
				facedict[x]=name
			f = open('facedict.pickle','wb')
			pickle.dump(facedict,f)
			f.close()
			while not isStartRegister:
				pass
			add_face('myface', faceIdList)
			print('Account [%s] is set'%name)
			user = Person(name) 
			personlist[name] = user
			
#####################     有改动       ##############
			wechat=input('Do you want to accept from wechat?(y or n)')
			if wechat == 'y':
				plt.imshow('gakki.jpg')
				plt.pause(10)       #暂停10秒
				plt.close()
				task = threading.Thread(target=wechat_time,args=(name,))	#线程：得到当前加的好友昵称
				task.start()
			if wechat == 'n':
				break
			break
		else:
			break



	

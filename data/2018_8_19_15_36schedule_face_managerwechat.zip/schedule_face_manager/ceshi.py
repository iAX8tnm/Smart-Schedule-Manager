import itchat

itchat.auto_login(hotReload = True, enableCmdQR = 2)
print('yes')
f = itchat.get_friends(update=True)
print(f)

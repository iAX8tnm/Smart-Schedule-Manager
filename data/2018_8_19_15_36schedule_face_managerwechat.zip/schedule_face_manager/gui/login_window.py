# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'c:\Users\yuanc\Desktop\aiui\schedule_face_manager\gui\res\login_window.ui'
#
# Created by: PyQt5 UI code generator 5.6
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_login_window(object):
    def setupUi(self, login_window):
        login_window.setObjectName("login_window")
        login_window.resize(1280, 800)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(login_window.sizePolicy().hasHeightForWidth())
        login_window.setSizePolicy(sizePolicy)
        login_window.setMinimumSize(QtCore.QSize(1280, 800))
        login_window.setMaximumSize(QtCore.QSize(1280, 800))
        self.centralwidget = QtWidgets.QWidget(login_window)
        self.centralwidget.setObjectName("centralwidget")
        self.label_background = QtWidgets.QLabel(self.centralwidget)
        self.label_background.setGeometry(QtCore.QRect(0, 0, 1280, 800))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_background.sizePolicy().hasHeightForWidth())
        self.label_background.setSizePolicy(sizePolicy)
        self.label_background.setMinimumSize(QtCore.QSize(1280, 800))
        self.label_background.setMaximumSize(QtCore.QSize(1280, 800))
        self.label_background.setText("")
        self.label_background.setPixmap(QtGui.QPixmap(":/background/background.png"))
        self.label_background.setScaledContents(True)
        self.label_background.setAlignment(QtCore.Qt.AlignCenter)
        self.label_background.setObjectName("label_background")
        self.pic_people = QtWidgets.QLabel(self.centralwidget)
        self.pic_people.setGeometry(QtCore.QRect(200, 200, 400, 400))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pic_people.sizePolicy().hasHeightForWidth())
        self.pic_people.setSizePolicy(sizePolicy)
        self.pic_people.setMinimumSize(QtCore.QSize(400, 400))
        self.pic_people.setMaximumSize(QtCore.QSize(400, 400))
        self.pic_people.setText("")
        self.pic_people.setPixmap(QtGui.QPixmap(":/other/pic_people.png"))
        self.pic_people.setScaledContents(True)
        self.pic_people.setAlignment(QtCore.Qt.AlignCenter)
        self.pic_people.setObjectName("pic_people")
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(949, 350, 171, 134))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setSpacing(70)
        self.verticalLayout.setObjectName("verticalLayout")
        self.btn_take_pic = QtWidgets.QPushButton(self.verticalLayoutWidget)
        font = QtGui.QFont()
        font.setFamily("Microsoft YaHei UI")
        font.setPointSize(12)
        self.btn_take_pic.setFont(font)
        self.btn_take_pic.setObjectName("btn_take_pic")
        self.verticalLayout.addWidget(self.btn_take_pic)
        self.btn_exit = QtWidgets.QPushButton(self.verticalLayoutWidget)
        font = QtGui.QFont()
        font.setFamily("Microsoft YaHei UI")
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.btn_exit.setFont(font)
        self.btn_exit.setObjectName("btn_exit")
        self.verticalLayout.addWidget(self.btn_exit)
        login_window.setCentralWidget(self.centralwidget)

        self.retranslateUi(login_window)
        self.btn_exit.clicked.connect(login_window.close)
        QtCore.QMetaObject.connectSlotsByName(login_window)

    def retranslateUi(self, login_window):
        _translate = QtCore.QCoreApplication.translate
        login_window.setWindowTitle(_translate("login_window", "login_window"))
        self.btn_take_pic.setText(_translate("login_window", "拍照"))
        self.btn_exit.setText(_translate("login_window", "退出"))

import gui.source_rc

# -*- coding:utf-8 -*-
import os
import pickle

personlist = None
facedict = None

def init_personlist():
    global personlist
    if not os.path.exists('person_list.pickle'):
        personlist={}
    else:
        try:
            f = open('person_list.pickle','rb')
            personlist=pickle.load(f)
            print(2)
            f.close
        except EOFError:
            personlist={}
            print(3)

    
def init_facedict():
    global facedict
    if not os.path.exists('facedict.pickle'):
        facedict={}
    else:
        try:
            f = open('facedict.pickle','rb')
            facedict=pickle.load(f)
            f.close
        except EOFError:
            pass

def set_personlist(name, value):

    personlist[name] = value

def set_facedict(token, name):

    facedict[token] = name

def update_personlist(new_list):

    personlist = new_list

def get_personlist(defValue=None):
    try:
        return personlist
    except KeyError:
        return defValue

def get_facedict(defValue=None):
    try:
        return facedict
    except KeyError:
        return defValue


